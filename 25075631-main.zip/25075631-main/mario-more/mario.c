#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //Prompt for height
    int Height;
    do
    {
        Height = get_int("Height from 1 to 8: ");
    }

    while (Height < 1 || Height > 8);

    for (int i = 1; Height >= i; i++)
    {
        //Spaces to the left equals height minus i
        for (int j = Height - i; j > 0; j--)
        {
            printf(" ");
        }

        //Increase left mario blocks
        for (int j = 1; j <= i; j++)
        {
            printf("#");
        }

        //Constant double space between
        printf("  ");

        //Increase right mario blocks
        for(int j = 1; j <= i; j++)
        {
            printf("#");
        }
        
        //Vertical axis
        printf("\n");
    }
}