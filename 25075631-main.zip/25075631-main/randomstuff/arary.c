#include <studio.h>
#include <cs50.h>

int main()
{
    int length;
    do
    {
        length = get_int("Length? ");
    }
    while (length < 1);



    int array[length];
    for (int i = 1; i < length; i++)
    {
        
    }
}