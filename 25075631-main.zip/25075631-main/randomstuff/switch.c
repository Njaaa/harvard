#include <stdio.h>
#include <cs50.h>

int main(void);

{
int x = get_int();

    if (x < 50)
    {
        printf("ayyy\n");

    }
}
